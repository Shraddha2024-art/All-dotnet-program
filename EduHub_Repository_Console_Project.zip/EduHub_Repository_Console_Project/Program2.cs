using System;
using System.Data;
using System.Runtime.InteropServices;
using EduHub_Repository_Console_Project.Models;
using EduHub_Repository_Console_Project.Repository;

namespace EduHub_Repository_Console_Project

{
    class Program2
    {
        static void Main(string[] args)
        {
            UserRepository userRepository = new UserRepository();
            System.Console.WriteLine("Login page");
            System.Console.WriteLine("Enter username ");
            string? username = Console.ReadLine();
            System.Console.WriteLine("Enter passward ");
            string? passward = Console.ReadLine();
            User user = userRepository.Login(username, passward);
            string role = string.Empty;
            if (user != null)
            {
                System.Console.WriteLine($"User Exist \n {user.UserName}-{user.Password}-{user.Email}");
                role = user.UserRole;
                if (role == "Educator")
                {
                    EducatorDashboard();
                }
                else
                {
                    System.Console.WriteLine("User does not exist");
                }
            }
        }

        public static void EducatorDashboard()
        {
            CourseRepository repo = new CourseRepository();
            int menu;
            System.Console.WriteLine("Press 1 for Allcourses \n 2 for Mycourses\n 3 for Add New Couses \n 4 for MyStudents\n 5 for Feedback list");
            menu = Convert.ToInt32(Console.ReadLine());
            switch (menu)
            {
                case 1:
                    System.Console.WriteLine("Show All Courses");
                    DataSet ds = new DataSet();
                    ds = repo.GetAllCourses();


                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        System.Console.WriteLine("Data is empty");

                    }
                    else
                    {
                        foreach (DataRow row in ds.Tables[0].Rows)
                        {
                            System.Console.WriteLine($"CourseId : {row["CourseId"]}  Course name :-  {row["Title"]}");
                        }

                    }
                    break;

                case 2:
                    System.Console.WriteLine("show MyCourses");
                    break;

                case 3:
                    System.Console.WriteLine("Add new Courses");
                    Course course = new Course();


                    System.Console.WriteLine("Enter Title");
                    course.Title = Console.ReadLine();


                    System.Console.WriteLine("Enter Description ");
                    course.Description = Console.ReadLine();

                    System.Console.WriteLine("Enter Start Date ");
                    course.CourseStartDate = Convert.ToDateTime(Console.ReadLine());

                    System.Console.WriteLine("Enter End Date");
                    course.CourseEndDate = Convert.ToDateTime(Console.ReadLine());

                    System.Console.WriteLine("Enter User Id");
                    course.UserId = Convert.ToInt32(Console.ReadLine());

                    System.Console.WriteLine("Enter Category ");
                    course.Category = Console.ReadLine();
                    System.Console.WriteLine("Enter Level ");
                    course.Level = Console.ReadLine();


                    int noOfRows = repo.AddCourse(course);
                    if (noOfRows > 0)
                    {
                        System.Console.WriteLine("user added successfully");
                    }
                    else
                    {
                        System.Console.WriteLine("user add fail");

                    }


                    break;

                case 4:
                    System.Console.WriteLine("For MyStudent");
                    break;

                case 5:
                    System.Console.WriteLine("Feedback List ");
                    break;


            }
        }
    }
}